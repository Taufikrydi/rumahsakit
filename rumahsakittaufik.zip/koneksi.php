<?php 
   $hostname  = "localhost";
   $username  = "root";
   $password  = "";
   $dbname  = "warehouse";
   $db = new mysqli($hostname, $username, $password, $dbname);
?>