<?php
   session_start();
   session_destroy();
?>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
<div align="center">
  <h2>Anda telah berhasil logout..</h2>
  Silahkan klik <a href="login.php" button type="button" class="btn btn-warning btn-sm">disini</a> untuk login kembali
</div>